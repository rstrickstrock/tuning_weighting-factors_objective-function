for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst
    rm -rf oplsaa-andi.ff
    cd 01_emin
    rm mdout.mdp slurm-*
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ../02_nvt/
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ../03_npt/
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ../04_prod/
    ln -s ../../../../oplsaa-andi.ff/ .
    
    cd ../../
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
