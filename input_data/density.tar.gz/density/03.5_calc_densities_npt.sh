output_file="/home/rstric2s/current_sim/Paper_Octane-2/study_transferability/density/13_density_npt.txt"

for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst/03_npt
    dens=$(echo "Density" | gmx energy -f npt.edr -o density_npt | grep "Density"  | awk '{print $2}')
    echo -e "$dens $tempdir $subst" >>$output_file
    cd ../..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
