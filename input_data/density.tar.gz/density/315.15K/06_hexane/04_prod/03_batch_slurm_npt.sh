#!/bin/bash
#SBATCH --partition=hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=26o1npt

gmx grompp -f 03_npt.mdp -c confout.gro -t nvt.cpt -p topol.top -o npt.tpr

gmx mdrun -ntmpi 1 -v -deffnm npt
