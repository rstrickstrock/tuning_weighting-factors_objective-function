#!/bin/bash
#SBATCH --partition=hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=9o1nvt

gmx grompp -f 02_nvt.mdp -c confout.gro -p topol.top -o nvt.tpr

gmx mdrun -v -deffnm nvt
