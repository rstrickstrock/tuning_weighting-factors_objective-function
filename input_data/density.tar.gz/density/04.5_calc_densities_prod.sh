output_file="/home/rstric2s/current_sim/Paper_Octane-2/study_transferability/density/14_density_prod.txt"
if [ -f $output_file ]
then
  rm $output_file
fi

for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst/04_prod/
    if [ -f "#density*" ]
    then
      rm "#density.*"
    fi
    dens_line=$(echo "Density" | gmx energy -f prod.edr -o density_prod | grep "Density" )
    dens=$(echo $dens_line | awk '{print $2}') 
    dens_err=$(echo $dens_line | awk '{print $3}')
    echo -e "$dens $dens_err $tempdir $subst" >>$output_file
    cd ../..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
