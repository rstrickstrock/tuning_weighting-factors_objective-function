for temp in "293.15K" "315.15K" "338.15K"
do
  cd $temp
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst
    mkdir 04_backup.bac
    for proddir in "04_prod-01" "04_prod-02" "04_prod-03" "04_prod-04" "04_prod-05" "04_prod-06" "04_prod-07" "04_prod-08" "04_prod-09" "04_prod-10"
    do
      mv $proddir 04_backup.bac
      mv 04_backup/$proddir .
    done
    mv 04_backup.bac/* 04_backup/
    rm -rf 04_backup.bac
    echo "$subst done."
    cd ..
    #break
  done
  echo "$temp done."
  echo ""
  cd ..
  #break
done
