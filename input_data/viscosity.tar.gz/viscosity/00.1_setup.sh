for temp in "293.15K" "315.15K" "338.15K"
do
  cd $temp
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst
    rm -rf initial_parameters/
    
    mv optimized_parameters/confout.gro .
    sed 's/opls_135 opls_135    1    1.72960e-01    6.57620e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <optimized_parameters/topol.top >optimized_parameters/topol.tmp
    sed 's/opls_136 opls_136    1    1.72960e-01    6.57620e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <optimized_parameters/topol.tmp >optimized_parameters/topol.top
    sed s'/opls_140 opls_140    1    1.50850e-01    7.98700e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <optimized_parameters/topol.top >topol.top
    
    mkdir 01_emin/
    cd 01_emin/
    mv ../optimized_parameters/01_emin/01_batch_slurm_emin.sh .
    ln -s ../confout.gro .
    ln -s ../topol.top .
    ln -s ../../01_emin.mdp
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    mkdir 02_npt
    cd 02_npt/
    mv ../optimized_parameters/02_npt/02_batch_slurm_npt.sh .
    ln -s ../01_emin/emin.gro confout.gro
    ln -s ../topol.top .
    ln -s ../../02_npt.mdp
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    mkdir 03_nvt
    cd 03_nvt/
    mv ../optimized_parameters/03_nvt/03_batch_slurm_nvt.sh .
    ln -s ../02_npt/npt.gro confout.gro
    ln -s ../02_npt/npt.cpt .
    ln -s ../topol.top .
    ln -s ../../03_nvt.mdp .
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    for proddir in "01" "02" "03" "04" "05" "06" "07" "08" "09" "10"
    do
      mkdir 04_prod-$proddir
      cd 04_prod-$proddir
      mv ../optimized_parameters/04_prod-$proddir/04_batch_slurm_prod.sh .
      ln -s ../03_nvt/nvt.gro confout.gro
      ln -s ../03_nvt/nvt.cpt .
      ln -s ../topol.top .
      ln -s ../../04_prod.mdp .
      ln -s ../../../../oplsaa-andi.ff/ .
      cd ..
    done
    
    rm -rf optimized_parameters/
    
    cd ..
  done
  cd ..
done
