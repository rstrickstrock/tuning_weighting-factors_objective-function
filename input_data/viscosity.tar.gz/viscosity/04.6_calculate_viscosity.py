import os
import numpy as np


cwd = os.getcwd()
outfile = os.path.join(cwd, "viscosities.txt")
subdirs = ["viscosity_files"]
temperatures = ["293.15K", "315.15K", "338.15K"]
substances = ["06_hexane", "07_heptane", "08_octane", "09_nonane"]
viscosityFiles = ["viscosity_01.xvg", "viscosity_02.xvg", "viscosity_03.xvg", "viscosity_04.xvg", "viscosity_05.xvg", "viscosity_06.xvg", "viscosity_07.xvg", "viscosity_08.xvg", "viscosity_09.xvg", "viscosity_10.xvg"]


def read_xvg(file):
    f = open(file, 'r')
    lines = f.readlines()
    f.close()

    time = []
    value = []

    for line in lines:
        if line.startswith("#") or line.startswith("@"):
            pass
        else:
            tmp = []
            for item in line.split(" "):
                if len(item) > 0:
                    #print(str(float(item)))
                    tmp.append(str(float(item)))
            time.append(tmp[0])
            value.append(tmp[1])

    #print(time)
    #print(value)
    return time, value



def calculate_mean(array):
    tmp = 0.0
    for i in range(0, len(array)):
        tmp = tmp + float(array[i])

    mean = tmp/len(array)
    return float(mean)

def calculate_viscosity(viscosities):
    mean = calculate_mean(viscosities) 
    stdDev = np.std(viscosities)
    #print(stdDev)
    error = 1/np.sqrt(len(viscosities)/10) * stdDev
    error = error * 1000.0 #unit shift
    #print(error)
    viscosity = mean # units: cP = 10^-3 Pa*s
    viscosity = viscosity * 1000.0 # units: u Pa*s
    return float(viscosity), float(error)


if os.path.isfile(outfile):
   os.remove(outfile)

out = open(outfile, 'w')

for subdir in subdirs:
    for temperature in temperatures:
        for substance in substances:
            viscosities = []
            for viscosityFile in viscosityFiles:
                path = os.path.join(subdir, temperature, substance)
                if os.path.isfile(os.path.join(path, viscosityFile)):
                    pass
                else:
                    break
                time, viscosity = read_xvg(os.path.join(path, viscosityFile))
                #print(viscosity)
                #exit()
                for visc in viscosity:
                    viscosities.append(float(visc))
            if len(viscosities) >= 1:
                viscosity, error = calculate_viscosity(viscosities)
                out.write(str(temperature) + " " + str(substance) + " " + str(viscosity) + " " + str(error) + "\n")
                #out.close()
                #exit()
            else:
                out.write("check: " + str(temperature) + " " + str(substance) + "\n")
        out.write("\n")
        print("done with {}.".format(temperature))
out.close()
























