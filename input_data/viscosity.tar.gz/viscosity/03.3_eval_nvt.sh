for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst/03_nvt
    echo "Potential" | gmx energy -f nvt.edr -o potential && xmgrace potential.xvg &
    #echo "Temperature" | gmx energy -f nvt.edr -o temperature && xmgrace temperature.xvg &
    cd ../..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
