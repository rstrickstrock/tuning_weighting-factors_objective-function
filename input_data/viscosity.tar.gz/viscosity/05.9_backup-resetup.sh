for temp in "293.15K" "315.15K" "338.15K"
do
  cd $temp
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst
    #mv 04_backup 04_backup.bac
    if [ -d 04_backup ]
    then
      rm -rf 04_backup
    fi
    mkdir 04_backup
    for proddir in "04_prod-01" "04_prod-02" "04_prod-03" "04_prod-04" "04_prod-05" "04_prod-06" "04_prod-07" "04_prod-08" "04_prod-09" "04_prod-10"
    do
      mv $proddir 04_backup/
      mkdir $proddir
      #pwd
      
      #sed 's/--partition=hpc3/--partition=hpc1,hpc3/' <"04_backup/$proddir/04_batch_slurm_prod.sh" >$proddir/04_batch_slurm_prod.sh
      cp 04_backup/$proddir/04_batch_slurm_prod.sh $proddir
      cd $proddir
      #cp 04_prod.mdp ../../$proddir
      ln -s ../../04_prod.mdp .
      #cp confout.gro ../../$proddir
      ln -s ../03_nvt/nvt.gro confout.gro
      #cp nvt.cpt ../../$proddir
      ln -s ../03_nvt/nvt.cpt .
      #cp oplsaa-andi.ff ../../$proddir
      ln -s ../../../../oplsaa-andi.ff/ .
      #cp topol.top ../../$proddir
      ln -s ../topol.top .
      cd ..
      #pwd
      #echo "$proddir done."
      #break
    done
    cd ..
    echo "$subst done."
    #break
  done
  cd ..
  echo "$temp done."
  echo ""
  #break
done
