sed 's/opls_135 opls_135    1    1.72960e-01    6.57620e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <06_hexane.top >06_hexane.tmp
sed 's/opls_136 opls_136    1    1.72960e-01    6.57620e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <06_hexane.tmp >06_hexane.top
sed s'/opls_140 opls_140    1    1.50850e-01    7.98700e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <06_hexane.top >06_hexane.tmp
mv 06_hexane.tmp 06_hexane.top

sed 's/opls_135 opls_135    1    1.72960e-01    6.57620e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <07_heptane.top >07_heptane.tmp
sed 's/opls_136 opls_136    1    1.72960e-01    6.57620e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <07_heptane.tmp >07_heptane.top
sed s'/opls_140 opls_140    1    1.50850e-01    7.98700e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <07_heptane.top >07_heptane.tmp
mv 07_heptane.tmp 07_heptane.top

sed 's/opls_135 opls_135    1    1.72960e-01    6.57620e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <08_octane.top >08_octane.tmp
sed 's/opls_136 opls_136    1    1.72960e-01    6.57620e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <08_octane.tmp >08_octane.top
sed s'/opls_140 opls_140    1    1.50850e-01    7.98700e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <08_octane.top >08_octane.tmp
mv 08_octane.tmp 08_octane.top

sed 's/opls_135 opls_135    1    1.72960e-01    6.57620e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <09_nonane.top >09_nonane.tmp
sed 's/opls_136 opls_136    1    1.72960e-01    6.57620e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <09_nonane.tmp >09_nonane.top
sed s'/opls_140 opls_140    1    1.50850e-01    7.98700e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <09_nonane.top >09_nonane.tmp
mv 09_nonane.tmp 09_nonane.top

for tempdir in "293.15K" "315.15K" "338.15K"
do
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cp $subst.top $tempdir/$subst/topol.top
  done
done
