cd viscosity_files

for temperature in "293.15K" "315.15K" "338.15K"
do
  cd $temperature
  for substance in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    mv $substance/viscosities_mean.xvg viscosities_mean_$temperature.$substance.xvg
  done
  cd ..
done

cd ..
