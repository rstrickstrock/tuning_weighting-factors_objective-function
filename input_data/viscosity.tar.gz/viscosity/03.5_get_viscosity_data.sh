cwd=$(pwd)

directory=$cwd/"viscosity_files-03_nvt"
if [[ -d $directory ]]; then
   rm -rf $directory
fi

mkdir $directory

for temp in "293.15K" "315.15K" "338.15K"
do
   cd $temp
   for substance in "06_hexane" "07_heptane" "08_octane" "09_nonane"
   do
      cd $substance/03_nvt/
      mkdir -p $directory/$temp/$substance/
      echo $(n=$(tail -1 nvt.gro | awk '{print $1}') && python -c "print($n*$n*$n)") | gmx energy -f nvt.edr -vis viscosity 
      mv viscosity.xvg $directory/$temp/$substance/
      cd ../..
   done
   cd ..
done
