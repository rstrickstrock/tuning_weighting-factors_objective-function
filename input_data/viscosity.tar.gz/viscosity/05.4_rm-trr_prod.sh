for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst/
    for n in "01" "02" "03" "04" "05" "06" "07" "08" "09" "10"
    do
      cd 04_prod-$n
      rm *trr
      cd ..
    done
    cd ../
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
