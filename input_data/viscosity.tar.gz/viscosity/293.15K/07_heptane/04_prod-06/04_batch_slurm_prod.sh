#!/bin/bash
#SBATCH --partition=hpc1,hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=17oVprod

gmx grompp -f 04_prod.mdp -c confout.gro -t nvt.cpt -p topol.top -o prod.tpr

gmx mdrun -ntmpi 1 -v -deffnm prod
