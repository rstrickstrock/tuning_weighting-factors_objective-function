#!/bin/bash
#SBATCH --partition=hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=18oVnvt

gmx grompp -f 03_nvt.mdp -c confout.gro -t npt.cpt -p topol.top -o nvt.tpr

gmx mdrun -ntmpi 1 -v -deffnm nvt
