cwd=$(pwd)

directory=$cwd/"viscosity_files"
if [[ -d $directory ]]; then
   rm -rf $directory
fi

mkdir $directory

for temp in "293.15K" "315.15K" "338.15K"
do
   cd $temp
   for substance in "06_hexane" "07_heptane" "08_octane" "09_nonane"
   do
      cd $substance
      mkdir -p $directory/$temp/$substance/
      for run in 04_prod-*; do
         cd $run  
         if [ -f prod.edr ]
         then 
            echo $(n=$(tail -1 ../03_nvt/nvt.gro | awk '{print $1}') && python -c "print($n*$n*$n)") | gmx energy -f prod.edr -vis viscosity_${run:8:2}
            mv viscosity_${run:8:2}.xvg $directory/$temp/$substance/$paramSet/
         fi
         cd ..
      done
      cd ..
   done
   cd ..
done
