import os
import numpy as np

cwd = os.getcwd()
subdirs = ["viscosity_files"]
temperatures = ["293.15K", "315.15K", "338.15K"]
substances = ["06_hexane", "07_heptane", "08_octane", "09_nonane"]
viscosityFiles = ["viscosity_01.xvg", "viscosity_02.xvg", "viscosity_03.xvg", "viscosity_04.xvg", "viscosity_05.xvg", "viscosity_06.xvg", "viscosity_07.xvg", "viscosity_08.xvg", "viscosity_09.xvg", "viscosity_10.xvg"]


def read_xvg(file):
    f = open(file, 'r')
    lines = f.readlines()
    f.close()

    time = []
    value = []

    for line in lines:
        if line.startswith("#") or line.startswith("@"):
            pass
        else:
            tmp = []
            for item in line.split(" "):
                if len(item) > 0:
                    #print(str(float(item)))
                    tmp.append(str(float(item)))
            time.append(tmp[0])
            value.append(tmp[1])

    #print(time)
    #print(value)
    return time, value


def calc_mean_visc(viscosity_array):
    # check if everything is the same length
    for i in range(0, len(viscosity_array)):
        if len(viscosity_array[0]) == len(viscosity_array[i]):
            pass
        else:
            print(f'Visocsities not equal length')
            break
    
    mean_viscosities = []
    for i in range(0, len(viscosity_array[0])):
        visc = 0
        for j in range(0, len(viscosity_array)):
            visc = visc + viscosity_array[j][i]
            
        visc = visc/len(viscosity_array)
        mean_viscosities.append(visc)
        #mean = np.mean(mean_viscosities)
    
    #return mean_viscosities, mean
    return mean_viscosities



for subdir in subdirs:
    for temperature in temperatures:
        for substance in substances:
        
            outfile = os.path.join(subdir, temperature, substance, "viscosities_mean.xvg")
            if os.path.isfile(outfile):
                os.remove(outfile) 
                
            viscosities_array = []
            for viscosityFile in viscosityFiles:
                viscosities = []
                path = os.path.join(subdir, temperature, substance)
                if os.path.isfile(os.path.join(path, viscosityFile)):
                    pass
                else:
                    break
                time, viscosity = read_xvg(os.path.join(path, viscosityFile))
                #print(viscosity)
                #exit()
                for visc in viscosity:
                    viscosities.append(float(visc))
                viscosities_array.append(viscosities)
                
            #viscosities_mean, mean = calc_mean_visc(viscosities_array)
            viscosities_mean = calc_mean_visc(viscosities_array)
            #print(f'{substance} {temperature} {mean}')
            with open(outfile, 'w') as out:
                for i in range(0, len(time)):
                    out.write(f'{time[i]}    {viscosities_mean[i]}\n')
                    
        print("done with {}.".format(temperature))

