#!/bin/bash
#SBATCH --partition=hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=26osemin

gmx grompp -f 01_emin.mdp -c confout.gro -p topol.top -o emin.tpr

gmx mdrun -v -deffnm emin
