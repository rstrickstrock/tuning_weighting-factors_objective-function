for tempdir in "293.15K" "315.15K" "338.15K"
do
  #ls -l $tempdir
  cd $tempdir
  for substdir in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    #echo $substdir
    cd $substdir
    if [ -d "initial_parameters" ]
    then
      rm -rf initial_parameters/
    fi
    
    mv optimized_parameters/run-01/out.gro .
    sed 's/opls_135 opls_135    1    1.70180e-01    4.57890e-01/opls_135 opls_135    1    3.28600e-01    6.73000e-01/' <optimized_parameters/run-01/topol.top >topol.top
    sed 's/opls_136 opls_136    1    1.70180e-01    4.57890e-01/opls_136 opls_136    1    3.28600e-01    6.73000e-01/' <topol.top >topol.tmp
    sed 's/opls_140 opls_140    1    1.52460e-01    4.47900e-02/opls_140 opls_140    1    2.60600e-01    1.19400e-01/' <topol.tmp >topol.top
    rm topol.tmp
    
    mkdir 01_emin
    mv optimized_parameters/run-01/01_emin/01_batch_slurm_emin.sh 01_emin/
    mv optimized_parameters/run-01/01_emin/01_emin.mdp 01_emin/
    mv optimized_parameters/run-01/01_emin/confout.gro 01_emin/
    mv optimized_parameters/run-01/01_emin/topol.top 01_emin/
    
    mkdir 02_nvt
    mv optimized_parameters/run-01/02_nvt/02_batch_slurm_nvt.sh 02_nvt/
    mv optimized_parameters/run-01/02_nvt/02_nvt.mdp 02_nvt/
    mv optimized_parameters/run-01/02_nvt/confout.gro 02_nvt/
    mv optimized_parameters/run-01/02_nvt/topol.top 02_nvt/
    
    mkdir 03_prod
    mv optimized_parameters/run-01/03_prod/03_batch_slurm_prod.sh 03_prod/
    mv optimized_parameters/run-01/03_prod/03_prod.mdp 03_prod/
    mv optimized_parameters/run-01/03_prod/confout.gro 03_prod/
    mv optimized_parameters/run-01/03_prod/nvt.cpt 03_prod/
    mv optimized_parameters/run-01/03_prod/topol.top 03_prod/
    
    rm -rf optimized_parameters/
    echo "$substdir done."
    cd ..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
