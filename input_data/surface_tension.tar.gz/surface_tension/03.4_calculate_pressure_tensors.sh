
cwd=$(pwd)

directory=$cwd/"pressure_files"
if [[ -d $directory ]]; then
   rm -rf $directory
fi
mkdir $directory

for temp in "293.15K" "315.15K" "338.15K"
do
  cd $temp
  for substance in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $substance/03_prod/
    echo "Pres-XX" | gmx energy -f prod.edr -o P_xx
    echo "Pres-YY" | gmx energy -f prod.edr -o P_yy
    echo "Pres-ZZ" | gmx energy -f prod.edr -o P_zz
    mkdir -p $directory/$temp/$substance/
    mv P_xx.xvg P_yy.xvg P_zz.xvg $directory/$temp/$substance/
    cd ../..
  done
  cd ..
done
