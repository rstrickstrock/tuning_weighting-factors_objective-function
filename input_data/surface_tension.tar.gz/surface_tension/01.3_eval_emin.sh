for tempdir in "293.15K" "315.15K" "338.15K"
do
  cd $tempdir
  for subst in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $subst/01_emin
    echo "Potential" | gmx energy -f emin.edr -o potential && xmgrace potential.xvg &
    cd ../..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
