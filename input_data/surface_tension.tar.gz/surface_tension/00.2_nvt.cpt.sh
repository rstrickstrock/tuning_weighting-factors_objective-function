for tempdir in "293.15K" "315.15K" "338.15K"
do
  #ls -l $tempdir
  cd $tempdir
  for substdir in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $substdir/03_prod
    ln -s ../02_nvt/nvt.cpt .
    cd ../..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
