for tempdir in "293.15K" "315.15K" "338.15K"
do
  #ls -l $tempdir
  cd $tempdir
  for substdir in "06_hexane" "07_heptane" "08_octane" "09_nonane"
  do
    cd $substdir
    
    cd 01_emin
    mv 01_emin.mdp ../../
    ln -s ../../01_emin.mdp .
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    cd 02_nvt
    mv 02_nvt.mdp ../../
    ln -s ../../02_nvt.mdp .
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    cd 03_prod
    mv 03_prod.mdp ../../
    ln -s ../../03_prod.mdp .
    ln -s ../../../../oplsaa-andi.ff/ .
    cd ..
    
    cd ..
  done
  echo "$tempdir done."
  echo ""
  cd ..
done
