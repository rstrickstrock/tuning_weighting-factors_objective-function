#!/bin/bash
#SBATCH --partition=hpc3
#SBATCH --nodes=1
#SBATCH --mem 20G
#SBATCH --time=72:00:00
#SBATCH --job-name=39isprod

gmx grompp -f 03_prod.mdp -c confout.gro -t nvt.cpt -p topol.top -o prod.tpr

gmx mdrun -v -deffnm prod
