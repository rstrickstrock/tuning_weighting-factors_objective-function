import os
import numpy as np

L_z = 10 #nm

cwd = os.getcwd()
outfile = os.path.join(cwd, "surface_tensions.txt")
subdirs = ["pressure_files"]
temperatures = ["293.15K", "315.15K", "338.15K"]
substances = ["06_hexane", "07_heptane", "08_octane", "09_nonane"]
pressureFiles = ["P_xx.xvg", "P_yy.xvg", "P_zz.xvg"]


def read_xvg(file):
    f = open(file, 'r')
    lines = f.readlines()
    f.close()

    time = []
    value = []

    for line in lines:
        if line.startswith("#") or line.startswith("@"):
            pass
        else:
            tmp = []
            for item in line.split(" "):
                if len(item) > 0:
                    #print(str(float(item)))
                    tmp.append(str(float(item)))
            time.append(tmp[0])
            value.append(tmp[1])

    #print(time)
    #print(value)
    return time, value



def calculate_mean(array):
    tmp = 0.0
    for i in range(0, len(array)):
        tmp = tmp + float(array[i])

    mean = tmp/len(array)
    return float(mean)

def calculate_surface_tension(L_z, pressure_x, pressure_y, pressure_z):
    tmp = []
    for i in range(0, len(pressure_x)):
        val = float(L_z) * (float(pressure_z[i]) - 0.5 * (float(pressure_x[i])+float(pressure_y[i])))
        tmp.append(val)

    mean = calculate_mean(tmp) 
    stdDev = np.std(tmp)
    #print(stdDev)
    error = 1/np.sqrt(len(tmp)) * stdDev
    error = error * 0.1 #unit shift
    #print(error*0.1)
    surface_tension = mean * 0.5 # units: 10^-4 N/m
    surface_tension = surface_tension * 0.1 # units: 10^-3 N/m
    return float(surface_tension), float(error)


#testfile =str(subdir[0] + "/" + temperatures[0] + "/" + substances[0] + "/" + parameterSets[0] + "/" + runs[0] + "/" + pressureFiles[0])
#print(testfile)
#time, value = read_xvg(testfile)
#print(len(time))
#print(len(value))

if os.path.isfile(outfile):
   os.remove(outfile)

out = open(outfile, 'w')

for subdir in subdirs:
    for temperature in temperatures:
        for substance in substances:
            path = os.path.join(subdir, temperature, substance)
            time_x, pressure_x = read_xvg(os.path.join(path, "P_xx.xvg"))
            time_y, pressure_y = read_xvg(os.path.join(path, "P_yy.xvg"))
            time_z, pressure_z = read_xvg(os.path.join(path, "P_zz.xvg"))
            #print(len(time_x))
            #print(len(pressure_x))
            #print(len(time_y))
            #print(len(pressure_y))
            #print(len(time_z))
            #print(len(pressure_z))
            surface_tension, error = calculate_surface_tension(L_z, pressure_x, pressure_y, pressure_z)
            #print(surface_tension, error)
            out.write(str(temperature) + " " + str(substance) + " " + str(surface_tension) + " " + str(error) + "\n")
            #out.close()
            #exit()
        out.write("\n")
out.close()





